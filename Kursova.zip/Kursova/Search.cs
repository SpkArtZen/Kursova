﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Forms;
using static Kursova.Manage_Person;
using Button = System.Windows.Forms.Button;
using Label = System.Windows.Forms.Label;
using Panel = System.Windows.Forms.Panel;

namespace Kursova
{
    public partial class Search : Form
    {
        SqlConnection connectionString = new SqlConnection(@"Data Source=ACER;Initial Catalog=Vacantion_kursosva;Integrated Security=True");
        List<Vacantion> vacantions = new List<Vacantion>();
        List<Citizen> citizens = new List<Citizen>();
        DataBase dataBase = new DataBase();


        public Search()
        {
            InitializeComponent();

        }
        private List<Citizen> GetCitizenData(string quer)
        {
            List<Citizen> citizens = new List<Citizen>();

            string query = $"SELECT c.ID_Citizen, c.Name, c.Surname, c.Birthdate, c.Adress, p.Phone, e.Education, s.Skill, c.Invalidity, c.Criminal_record " +
                           $"FROM Citizen c " +
                           $"LEFT JOIN Phone p ON c.ID_Citizen = p.ID_Citizen " +
                           $"LEFT JOIN Education e ON c.ID_Citizen = e.ID_Citizen " +
                           $"LEFT JOIN Citizen_Skills cs ON c.ID_Citizen = cs.ID_Citizen " +
                           $"LEFT JOIN Skill s ON cs.Skill_ID = s.Skill_ID " +
                           $"WHERE c.Name Like '%{quer}%' OR c.Surname Like '%{quer}%' OR c.Adress Like '%{quer}%'";

            using (SqlConnection connection = new SqlConnection(connectionString.ConnectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    int id = reader.GetInt32(0);
                    string name = reader.GetString(1);
                    string surname = reader.GetString(2);
                    DateTime birthdate = reader.GetDateTime(3);
                    string adress = reader.GetString(4);
                    string phone = reader.IsDBNull(5) ? null : reader.GetString(5); // Додано телефон
                    string education = reader.IsDBNull(6) ? null : reader.GetString(6); // Додано освіту
                    List<string> skills = new List<string>(); // Додано навички
                    bool inv = reader.GetBoolean(8); // Додано Invalidity
                    bool crime = reader.GetBoolean(9); // Додано Crime

                    do
                    {
                        string skill = reader.IsDBNull(7) ? null : reader.GetString(7);
                        if (skill != null)
                            skills.Add(skill);
                    } while (reader.Read() && id == reader.GetInt32(0));

                    reader.Close();
                    Citizen cit = new Citizen(id, name, surname, birthdate, adress, phone, education, skills, inv, crime);
                    citizens.Add(cit);
                }
            }

            return citizens;
        }
        private List<Vacantion> GetVacantionData(string query)
        {
            List<Vacantion> vacantions = new List<Vacantion>();

            string baseQuery = "SELECT ID_vacantion, ID_Employer, Post, Salary, Replacement_date, Type_of_employment, Company_name FROM Vacantion";
            string filter = string.Empty;

            if (!string.IsNullOrEmpty(query))
            {
                filter = " WHERE Post LIKE @query OR Company_name LIKE @query"; // Додано фільтрацію за посадою та назвою компанії
            }

            using (SqlConnection connection = new SqlConnection(connectionString.ConnectionString))
            {
                string sqlCommandText = baseQuery + filter;
                SqlCommand command = new SqlCommand(sqlCommandText, connection);

                if (!string.IsNullOrEmpty(query))
                {
                    command.Parameters.AddWithValue("@query", $"%{query}%");
                }

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    int id = reader.GetInt32(0);
                    int employerId = reader.GetInt32(1);
                    string post = reader.GetString(2);
                    int salary = reader.GetInt32(3);
                    DateTime replacementDate = reader.GetDateTime(4);
                    string typeOfEmployment = reader.GetString(5);
                    string companyName = reader.GetString(6);

                    Vacantion vacantion = new Vacantion(id, employerId, post, salary, replacementDate, typeOfEmployment, companyName);
                    vacantions.Add(vacantion);
                }
            }

            return vacantions;
        }



        private void searchTextBox_TextChanged(object sender, EventArgs e)
        {
            string query = searchTextBox.Text;
            tabControl1.TabPages.Clear();
            if (citizenRadioButton.Checked)
            {
                vacantions.Clear();
                vacantions = GetVacantionData(query);
                if (!string.IsNullOrEmpty(query))
                {

                    DisplayVacantions(vacantions);
                    searchTextBox.Focus(); // Зберігаємо фокус на TextBox
                }
            }
            else if (vacantionRadioButton.Checked)
            {
                citizens.Clear();
                citizens = GetCitizenData(query);
                if (!string.IsNullOrEmpty(query))
                {

                   
                    searchTextBox.Focus(); // Зберігаємо фокус на TextBox
                }
            }
        }
        private void DisplayVacantions(List<Vacantion> vacantions)
        {
            int tabPageIndex = 0;
            int rowCount = 0;
            int colCount = 0;
            int labelLeft = 10;
            int labelWidth = 200;
            int labelHeight = 20;
            int verticalGap = 2;
            int panelWidth = 275;
            int panelHeight = 175;

            tabControl1.TabPages.Clear(); // Очищаємо вкладки

            TabPage tabPage = new TabPage("Сторінка 1");
            tabControl1.TabPages.Add(tabPage);

            foreach (var vacantion in vacantions)
            {
                if (rowCount == 4)
                {
                    tabPageIndex++;
                    tabPage = new TabPage("Сторінка " + (tabPageIndex + 1));
                    tabControl1.TabPages.Add(tabPage);
                    rowCount = 0;
                    colCount = 0;
                }

                Panel panel = new Panel();
                panel.BorderStyle = BorderStyle.FixedSingle;
                panel.Top = 10 + (panelHeight + verticalGap) * rowCount;
                panel.Left = 10 + ((panelWidth + labelLeft * 2 + 5) * colCount);
                panel.Width = panelWidth;
                panel.Height = panelHeight;

                Label nameLabel = new Label();
                nameLabel.Text = "Посада: " + vacantion.Post;
                nameLabel.Left = labelLeft;
                nameLabel.Top = 10;
                nameLabel.Width = labelWidth;
                nameLabel.Height = labelHeight;

                Label idLabel = new Label();
                idLabel.Text = "ID: " + vacantion.ID;
                idLabel.Left = labelLeft;
                idLabel.Top = nameLabel.Bottom + verticalGap;
                idLabel.Width = labelWidth;
                idLabel.Height = labelHeight;

                Label salaryLabel = new Label();
                salaryLabel.Text = "Зарплата: " + vacantion.Salary;
                salaryLabel.Left = labelLeft;
                salaryLabel.Top = idLabel.Bottom + verticalGap;
                salaryLabel.Width = labelWidth;
                salaryLabel.Height = labelHeight;

                Label replacementDateLabel = new Label();
                replacementDateLabel.Text = "Дата розміщення: " + vacantion.ReplacementDate.ToShortDateString();
                replacementDateLabel.Left = labelLeft;
                replacementDateLabel.Top = salaryLabel.Bottom + verticalGap;
                replacementDateLabel.Width = labelWidth;
                replacementDateLabel.Height = labelHeight;

                Label typeOfEmploymentLabel = new Label();
                typeOfEmploymentLabel.Text = "Тип зайнятості: " + vacantion.TypeOfEmployment;
                typeOfEmploymentLabel.Left = labelLeft;
                typeOfEmploymentLabel.Top = replacementDateLabel.Bottom + verticalGap;
                typeOfEmploymentLabel.Width = labelWidth;
                typeOfEmploymentLabel.Height = labelHeight;

                Label companyNameLabel = new Label();
                companyNameLabel.Text = "Назва компанії: " + vacantion.CompanyName;
                companyNameLabel.Left = labelLeft;
                companyNameLabel.Top = typeOfEmploymentLabel.Bottom + verticalGap;
                companyNameLabel.Width = labelWidth;
                companyNameLabel.Height = labelHeight;

                panel.Controls.Add(nameLabel);
                panel.Controls.Add(idLabel);
                panel.Controls.Add(salaryLabel);
                panel.Controls.Add(replacementDateLabel);
                panel.Controls.Add(typeOfEmploymentLabel);
                panel.Controls.Add(companyNameLabel);
                tabPage.Controls.Add(panel);

                rowCount++;
                if (rowCount > 1)
                {
                    rowCount = 0;
                    colCount++;
                }
            }
        }
        
        public partial class Vacantion
        {
            public int ID { get; set; }
            public int EmployerID { get; set; }
            public string Post { get; set; }
            public double Salary { get; set; }
            public DateTime ReplacementDate { get; set; }
            public string TypeOfEmployment { get; set; }
            public string CompanyName { get; set; }

            public Vacantion(int id, int employerId, string post, double salary, DateTime replacementDate, string typeOfEmployment, string companyName)
            {
                ID = id;
                EmployerID = employerId;
                Post = post;
                Salary = salary;
                ReplacementDate = replacementDate;
                TypeOfEmployment = typeOfEmployment;
                CompanyName = companyName;
            }
        }
    }
}
