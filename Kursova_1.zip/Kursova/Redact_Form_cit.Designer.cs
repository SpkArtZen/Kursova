﻿namespace Kursova
{
    partial class Redact_Form_cit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Comment = new System.Windows.Forms.TextBox();
            this.Remove = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.text_phone = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Add = new System.Windows.Forms.Button();
            this.phones_cit = new System.Windows.Forms.ComboBox();
            this.Comm_manage = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.checkCrime = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.butt_ = new System.Windows.Forms.Button();
            this.checkInv = new System.Windows.Forms.CheckBox();
            this.butt_date = new System.Windows.Forms.Button();
            this.name_text = new System.Windows.Forms.TextBox();
            this.butt_sur = new System.Windows.Forms.Button();
            this.surname_text = new System.Windows.Forms.TextBox();
            this.but_name = new System.Windows.Forms.Button();
            this.adress_text = new System.Windows.Forms.TextBox();
            this.year = new System.Windows.Forms.ComboBox();
            this.month = new System.Windows.Forms.ComboBox();
            this.day = new System.Windows.Forms.ComboBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Citizen = new System.Windows.Forms.TabPage();
            this.Documents = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Update_panel = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.update_doc = new System.Windows.Forms.Button();
            this.number_doc_change = new System.Windows.Forms.TextBox();
            this.day_doc_change = new System.Windows.Forms.ComboBox();
            this.month_doc_change = new System.Windows.Forms.ComboBox();
            this.year_doc_change = new System.Windows.Forms.ComboBox();
            this.choose_doc = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.update_doc_radio = new System.Windows.Forms.RadioButton();
            this.add_doc_radio = new System.Windows.Forms.RadioButton();
            this.Add_panel = new System.Windows.Forms.Panel();
            this.add_doc = new System.Windows.Forms.Button();
            this.number_doc = new System.Windows.Forms.TextBox();
            this.day_doc = new System.Windows.Forms.ComboBox();
            this.month_doc = new System.Windows.Forms.ComboBox();
            this.year_doc = new System.Windows.Forms.ComboBox();
            this.type_doc = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.Education = new System.Windows.Forms.TabPage();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.btn_delete = new System.Windows.Forms.Button();
            this.combo_type = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btn_update = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.text_number = new System.Windows.Forms.TextBox();
            this.text_Type = new System.Windows.Forms.TextBox();
            this.Add_Educ = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.Update_Education = new System.Windows.Forms.RadioButton();
            this.Add_Education = new System.Windows.Forms.RadioButton();
            this.Skills_Citizen = new System.Windows.Forms.TabPage();
            this.remove_skill_data = new System.Windows.Forms.Button();
            this.add_skill_to_data = new System.Windows.Forms.Button();
            this.Remove_skill = new System.Windows.Forms.Button();
            this.button_sentSkill = new System.Windows.Forms.Button();
            this.CItizen_skills_data = new System.Windows.Forms.DataGridView();
            this.skill_box = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.Citizen.SuspendLayout();
            this.Documents.SuspendLayout();
            this.panel3.SuspendLayout();
            this.Update_panel.SuspendLayout();
            this.Add_panel.SuspendLayout();
            this.Education.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.Skills_Citizen.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CItizen_skills_data)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panel1.Controls.Add(this.label5);
            this.panel1.Location = new System.Drawing.Point(12, 23);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(587, 87);
            this.panel1.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(21, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(214, 38);
            this.label5.TabIndex = 0;
            this.label5.Text = "Редагування";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(576, 435);
            this.panel2.TabIndex = 2;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.AliceBlue;
            this.panel5.Controls.Add(this.Comment);
            this.panel5.Controls.Add(this.Remove);
            this.panel5.Controls.Add(this.label6);
            this.panel5.Controls.Add(this.label8);
            this.panel5.Controls.Add(this.text_phone);
            this.panel5.Controls.Add(this.label7);
            this.panel5.Controls.Add(this.Add);
            this.panel5.Controls.Add(this.phones_cit);
            this.panel5.Controls.Add(this.Comm_manage);
            this.panel5.Location = new System.Drawing.Point(6, 247);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(564, 188);
            this.panel5.TabIndex = 29;
            // 
            // Comment
            // 
            this.Comment.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Comment.Location = new System.Drawing.Point(25, 95);
            this.Comment.Multiline = true;
            this.Comment.Name = "Comment";
            this.Comment.Size = new System.Drawing.Size(346, 81);
            this.Comment.TabIndex = 15;
            // 
            // Remove
            // 
            this.Remove.Location = new System.Drawing.Point(351, 43);
            this.Remove.Name = "Remove";
            this.Remove.Size = new System.Drawing.Size(26, 23);
            this.Remove.TabIndex = 27;
            this.Remove.Text = "-";
            this.Remove.UseVisualStyleBackColor = true;
            this.Remove.Click += new System.EventHandler(this.Remove_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(25, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(116, 16);
            this.label6.TabIndex = 13;
            this.label6.Text = "Додати телефон";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(25, 73);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 16);
            this.label8.TabIndex = 26;
            this.label8.Text = "Коментар";
            // 
            // text_phone
            // 
            this.text_phone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.text_phone.Location = new System.Drawing.Point(25, 43);
            this.text_phone.Name = "text_phone";
            this.text_phone.Size = new System.Drawing.Size(126, 22);
            this.text_phone.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(217, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 16);
            this.label7.TabIndex = 25;
            this.label7.Text = "Видалити";
            // 
            // Add
            // 
            this.Add.Location = new System.Drawing.Point(157, 42);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(26, 23);
            this.Add.TabIndex = 16;
            this.Add.Text = "+";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // phones_cit
            // 
            this.phones_cit.FormattingEnabled = true;
            this.phones_cit.Location = new System.Drawing.Point(205, 42);
            this.phones_cit.Name = "phones_cit";
            this.phones_cit.Size = new System.Drawing.Size(136, 24);
            this.phones_cit.TabIndex = 24;
            this.phones_cit.SelectedIndexChanged += new System.EventHandler(this.phones_cit_SelectedIndexChanged);
            // 
            // Comm_manage
            // 
            this.Comm_manage.Location = new System.Drawing.Point(392, 95);
            this.Comm_manage.Name = "Comm_manage";
            this.Comm_manage.Size = new System.Drawing.Size(100, 23);
            this.Comm_manage.TabIndex = 21;
            this.Comm_manage.Text = "Оновити";
            this.Comm_manage.UseVisualStyleBackColor = true;
            this.Comm_manage.Click += new System.EventHandler(this.Comm_manage_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.AliceBlue;
            this.panel4.Controls.Add(this.checkCrime);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.butt_);
            this.panel4.Controls.Add(this.checkInv);
            this.panel4.Controls.Add(this.butt_date);
            this.panel4.Controls.Add(this.name_text);
            this.panel4.Controls.Add(this.butt_sur);
            this.panel4.Controls.Add(this.surname_text);
            this.panel4.Controls.Add(this.but_name);
            this.panel4.Controls.Add(this.adress_text);
            this.panel4.Controls.Add(this.year);
            this.panel4.Controls.Add(this.month);
            this.panel4.Controls.Add(this.day);
            this.panel4.Location = new System.Drawing.Point(6, 17);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(564, 224);
            this.panel4.TabIndex = 28;
            // 
            // checkCrime
            // 
            this.checkCrime.AutoSize = true;
            this.checkCrime.Location = new System.Drawing.Point(350, 159);
            this.checkCrime.Name = "checkCrime";
            this.checkCrime.Size = new System.Drawing.Size(158, 20);
            this.checkCrime.TabIndex = 5;
            this.checkCrime.Text = "Кримінальна історія";
            this.checkCrime.UseVisualStyleBackColor = true;
            this.checkCrime.CheckedChanged += new System.EventHandler(this.checkCrime_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ім\'я";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(151, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Прізвище";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(311, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(122, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Дата народження";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 130);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Адреса";
            // 
            // butt_
            // 
            this.butt_.Location = new System.Drawing.Point(24, 185);
            this.butt_.Name = "butt_";
            this.butt_.Size = new System.Drawing.Size(100, 23);
            this.butt_.TabIndex = 20;
            this.butt_.Text = "Оновити";
            this.butt_.UseVisualStyleBackColor = true;
            this.butt_.Click += new System.EventHandler(this.butt__Click);
            // 
            // checkInv
            // 
            this.checkInv.AutoSize = true;
            this.checkInv.Location = new System.Drawing.Point(219, 159);
            this.checkInv.Name = "checkInv";
            this.checkInv.Size = new System.Drawing.Size(107, 20);
            this.checkInv.TabIndex = 4;
            this.checkInv.Text = "Інвалідність";
            this.checkInv.UseVisualStyleBackColor = true;
            this.checkInv.CheckedChanged += new System.EventHandler(this.checkInv_CheckedChanged);
            // 
            // butt_date
            // 
            this.butt_date.Location = new System.Drawing.Point(350, 92);
            this.butt_date.Name = "butt_date";
            this.butt_date.Size = new System.Drawing.Size(142, 23);
            this.butt_date.TabIndex = 19;
            this.butt_date.Text = "Оновити";
            this.butt_date.UseVisualStyleBackColor = true;
            this.butt_date.Click += new System.EventHandler(this.butt_date_Click);
            // 
            // name_text
            // 
            this.name_text.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.name_text.Location = new System.Drawing.Point(24, 62);
            this.name_text.Name = "name_text";
            this.name_text.Size = new System.Drawing.Size(100, 22);
            this.name_text.TabIndex = 6;
            // 
            // butt_sur
            // 
            this.butt_sur.Location = new System.Drawing.Point(154, 90);
            this.butt_sur.Name = "butt_sur";
            this.butt_sur.Size = new System.Drawing.Size(100, 23);
            this.butt_sur.TabIndex = 18;
            this.butt_sur.Text = "Оновити";
            this.butt_sur.UseVisualStyleBackColor = true;
            this.butt_sur.Click += new System.EventHandler(this.butt_sur_Click);
            // 
            // surname_text
            // 
            this.surname_text.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.surname_text.Location = new System.Drawing.Point(154, 62);
            this.surname_text.Name = "surname_text";
            this.surname_text.Size = new System.Drawing.Size(100, 22);
            this.surname_text.TabIndex = 7;
            // 
            // but_name
            // 
            this.but_name.Location = new System.Drawing.Point(24, 90);
            this.but_name.Name = "but_name";
            this.but_name.Size = new System.Drawing.Size(100, 23);
            this.but_name.TabIndex = 17;
            this.but_name.Text = "Оновити";
            this.but_name.UseVisualStyleBackColor = true;
            this.but_name.Click += new System.EventHandler(this.but_name_Click);
            // 
            // adress_text
            // 
            this.adress_text.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.adress_text.Location = new System.Drawing.Point(24, 157);
            this.adress_text.Name = "adress_text";
            this.adress_text.Size = new System.Drawing.Size(169, 22);
            this.adress_text.TabIndex = 9;
            // 
            // year
            // 
            this.year.FormattingEnabled = true;
            this.year.Location = new System.Drawing.Point(304, 62);
            this.year.Name = "year";
            this.year.Size = new System.Drawing.Size(87, 24);
            this.year.TabIndex = 10;
            // 
            // month
            // 
            this.month.FormattingEnabled = true;
            this.month.Location = new System.Drawing.Point(397, 62);
            this.month.Name = "month";
            this.month.Size = new System.Drawing.Size(56, 24);
            this.month.TabIndex = 11;
            // 
            // day
            // 
            this.day.FormattingEnabled = true;
            this.day.Location = new System.Drawing.Point(459, 62);
            this.day.Name = "day";
            this.day.Size = new System.Drawing.Size(69, 24);
            this.day.TabIndex = 12;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Citizen);
            this.tabControl1.Controls.Add(this.Documents);
            this.tabControl1.Controls.Add(this.Education);
            this.tabControl1.Controls.Add(this.Skills_Citizen);
            this.tabControl1.Location = new System.Drawing.Point(12, 116);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(584, 464);
            this.tabControl1.TabIndex = 28;
            // 
            // Citizen
            // 
            this.Citizen.Controls.Add(this.panel2);
            this.Citizen.Location = new System.Drawing.Point(4, 25);
            this.Citizen.Name = "Citizen";
            this.Citizen.Padding = new System.Windows.Forms.Padding(3);
            this.Citizen.Size = new System.Drawing.Size(576, 435);
            this.Citizen.TabIndex = 0;
            this.Citizen.Text = "Громадянин";
            this.Citizen.UseVisualStyleBackColor = true;
            // 
            // Documents
            // 
            this.Documents.Controls.Add(this.panel3);
            this.Documents.Location = new System.Drawing.Point(4, 25);
            this.Documents.Name = "Documents";
            this.Documents.Padding = new System.Windows.Forms.Padding(3);
            this.Documents.Size = new System.Drawing.Size(576, 435);
            this.Documents.TabIndex = 1;
            this.Documents.Text = "Документи";
            this.Documents.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panel3.Controls.Add(this.Update_panel);
            this.panel3.Controls.Add(this.update_doc_radio);
            this.panel3.Controls.Add(this.add_doc_radio);
            this.panel3.Controls.Add(this.Add_panel);
            this.panel3.Location = new System.Drawing.Point(-4, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(580, 435);
            this.panel3.TabIndex = 0;
            // 
            // Update_panel
            // 
            this.Update_panel.BackColor = System.Drawing.Color.AliceBlue;
            this.Update_panel.Controls.Add(this.button2);
            this.Update_panel.Controls.Add(this.update_doc);
            this.Update_panel.Controls.Add(this.number_doc_change);
            this.Update_panel.Controls.Add(this.day_doc_change);
            this.Update_panel.Controls.Add(this.month_doc_change);
            this.Update_panel.Controls.Add(this.year_doc_change);
            this.Update_panel.Controls.Add(this.choose_doc);
            this.Update_panel.Controls.Add(this.label12);
            this.Update_panel.Controls.Add(this.label13);
            this.Update_panel.Controls.Add(this.label14);
            this.Update_panel.Location = new System.Drawing.Point(28, 41);
            this.Update_panel.Name = "Update_panel";
            this.Update_panel.Size = new System.Drawing.Size(527, 365);
            this.Update_panel.TabIndex = 9;
            this.Update_panel.Visible = false;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(138, 173);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 23);
            this.button2.TabIndex = 9;
            this.button2.Text = "Видалити";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // update_doc
            // 
            this.update_doc.Location = new System.Drawing.Point(26, 173);
            this.update_doc.Name = "update_doc";
            this.update_doc.Size = new System.Drawing.Size(106, 23);
            this.update_doc.TabIndex = 8;
            this.update_doc.Text = "Оновити";
            this.update_doc.UseVisualStyleBackColor = true;
            this.update_doc.Click += new System.EventHandler(this.update_doc_Click);
            // 
            // number_doc_change
            // 
            this.number_doc_change.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.number_doc_change.Location = new System.Drawing.Point(168, 123);
            this.number_doc_change.Name = "number_doc_change";
            this.number_doc_change.Size = new System.Drawing.Size(225, 22);
            this.number_doc_change.TabIndex = 7;
            // 
            // day_doc_change
            // 
            this.day_doc_change.FormattingEnabled = true;
            this.day_doc_change.Location = new System.Drawing.Point(298, 79);
            this.day_doc_change.Name = "day_doc_change";
            this.day_doc_change.Size = new System.Drawing.Size(48, 24);
            this.day_doc_change.TabIndex = 6;
            // 
            // month_doc_change
            // 
            this.month_doc_change.FormattingEnabled = true;
            this.month_doc_change.Location = new System.Drawing.Point(244, 79);
            this.month_doc_change.Name = "month_doc_change";
            this.month_doc_change.Size = new System.Drawing.Size(48, 24);
            this.month_doc_change.TabIndex = 5;
            // 
            // year_doc_change
            // 
            this.year_doc_change.FormattingEnabled = true;
            this.year_doc_change.Location = new System.Drawing.Point(168, 79);
            this.year_doc_change.Name = "year_doc_change";
            this.year_doc_change.Size = new System.Drawing.Size(70, 24);
            this.year_doc_change.TabIndex = 4;
            // 
            // choose_doc
            // 
            this.choose_doc.FormattingEnabled = true;
            this.choose_doc.Location = new System.Drawing.Point(168, 28);
            this.choose_doc.Name = "choose_doc";
            this.choose_doc.Size = new System.Drawing.Size(182, 24);
            this.choose_doc.TabIndex = 3;
            this.choose_doc.SelectedIndexChanged += new System.EventHandler(this.choose_doc_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(24, 125);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(127, 16);
            this.label12.TabIndex = 2;
            this.label12.Text = "Номер документа:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(24, 30);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(109, 16);
            this.label13.TabIndex = 0;
            this.label13.Text = "Тип документа:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(24, 82);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(72, 16);
            this.label14.TabIndex = 1;
            this.label14.Text = "Термін дії:\r\n";
            // 
            // update_doc_radio
            // 
            this.update_doc_radio.AutoSize = true;
            this.update_doc_radio.Location = new System.Drawing.Point(129, 15);
            this.update_doc_radio.Name = "update_doc_radio";
            this.update_doc_radio.Size = new System.Drawing.Size(153, 20);
            this.update_doc_radio.TabIndex = 10;
            this.update_doc_radio.TabStop = true;
            this.update_doc_radio.Text = "Оновити/Видалити";
            this.update_doc_radio.UseVisualStyleBackColor = true;
            // 
            // add_doc_radio
            // 
            this.add_doc_radio.AutoSize = true;
            this.add_doc_radio.Location = new System.Drawing.Point(30, 15);
            this.add_doc_radio.Name = "add_doc_radio";
            this.add_doc_radio.Size = new System.Drawing.Size(76, 20);
            this.add_doc_radio.TabIndex = 9;
            this.add_doc_radio.TabStop = true;
            this.add_doc_radio.Text = "Додати";
            this.add_doc_radio.UseVisualStyleBackColor = true;
            this.add_doc_radio.CheckedChanged += new System.EventHandler(this.add_doc_radio_CheckedChanged);
            // 
            // Add_panel
            // 
            this.Add_panel.BackColor = System.Drawing.Color.AliceBlue;
            this.Add_panel.Controls.Add(this.add_doc);
            this.Add_panel.Controls.Add(this.number_doc);
            this.Add_panel.Controls.Add(this.day_doc);
            this.Add_panel.Controls.Add(this.month_doc);
            this.Add_panel.Controls.Add(this.year_doc);
            this.Add_panel.Controls.Add(this.type_doc);
            this.Add_panel.Controls.Add(this.label11);
            this.Add_panel.Controls.Add(this.label9);
            this.Add_panel.Controls.Add(this.label10);
            this.Add_panel.Location = new System.Drawing.Point(28, 41);
            this.Add_panel.Name = "Add_panel";
            this.Add_panel.Size = new System.Drawing.Size(527, 365);
            this.Add_panel.TabIndex = 3;
            // 
            // add_doc
            // 
            this.add_doc.Location = new System.Drawing.Point(27, 173);
            this.add_doc.Name = "add_doc";
            this.add_doc.Size = new System.Drawing.Size(89, 23);
            this.add_doc.TabIndex = 8;
            this.add_doc.Text = "Додати";
            this.add_doc.UseVisualStyleBackColor = true;
            this.add_doc.Click += new System.EventHandler(this.add_doc_Click);
            // 
            // number_doc
            // 
            this.number_doc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.number_doc.Location = new System.Drawing.Point(172, 122);
            this.number_doc.Name = "number_doc";
            this.number_doc.Size = new System.Drawing.Size(178, 22);
            this.number_doc.TabIndex = 7;
            // 
            // day_doc
            // 
            this.day_doc.FormattingEnabled = true;
            this.day_doc.Location = new System.Drawing.Point(302, 79);
            this.day_doc.Name = "day_doc";
            this.day_doc.Size = new System.Drawing.Size(48, 24);
            this.day_doc.TabIndex = 6;
            // 
            // month_doc
            // 
            this.month_doc.FormattingEnabled = true;
            this.month_doc.Location = new System.Drawing.Point(248, 79);
            this.month_doc.Name = "month_doc";
            this.month_doc.Size = new System.Drawing.Size(48, 24);
            this.month_doc.TabIndex = 5;
            // 
            // year_doc
            // 
            this.year_doc.FormattingEnabled = true;
            this.year_doc.Location = new System.Drawing.Point(172, 79);
            this.year_doc.Name = "year_doc";
            this.year_doc.Size = new System.Drawing.Size(70, 24);
            this.year_doc.TabIndex = 4;
            // 
            // type_doc
            // 
            this.type_doc.FormattingEnabled = true;
            this.type_doc.Location = new System.Drawing.Point(172, 27);
            this.type_doc.Name = "type_doc";
            this.type_doc.Size = new System.Drawing.Size(178, 24);
            this.type_doc.TabIndex = 3;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(24, 125);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(127, 16);
            this.label11.TabIndex = 2;
            this.label11.Text = "Номер документа:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(24, 30);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(109, 16);
            this.label9.TabIndex = 0;
            this.label9.Text = "Тип документа:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(24, 82);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(72, 16);
            this.label10.TabIndex = 1;
            this.label10.Text = "Термін дії:\r\n";
            // 
            // Education
            // 
            this.Education.Controls.Add(this.panel6);
            this.Education.Location = new System.Drawing.Point(4, 25);
            this.Education.Name = "Education";
            this.Education.Size = new System.Drawing.Size(576, 435);
            this.Education.TabIndex = 2;
            this.Education.Text = "Освіта";
            this.Education.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panel6.Controls.Add(this.panel8);
            this.panel6.Controls.Add(this.panel7);
            this.panel6.Controls.Add(this.Update_Education);
            this.panel6.Controls.Add(this.Add_Education);
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(577, 435);
            this.panel6.TabIndex = 0;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.AliceBlue;
            this.panel8.Controls.Add(this.btn_delete);
            this.panel8.Controls.Add(this.combo_type);
            this.panel8.Controls.Add(this.textBox1);
            this.panel8.Controls.Add(this.btn_update);
            this.panel8.Controls.Add(this.label17);
            this.panel8.Controls.Add(this.label18);
            this.panel8.Location = new System.Drawing.Point(24, 41);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(524, 364);
            this.panel8.TabIndex = 5;
            this.panel8.Visible = false;
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(120, 170);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(75, 23);
            this.btn_delete.TabIndex = 6;
            this.btn_delete.Text = "Видалити";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // combo_type
            // 
            this.combo_type.FormattingEnabled = true;
            this.combo_type.Location = new System.Drawing.Point(120, 40);
            this.combo_type.Name = "combo_type";
            this.combo_type.Size = new System.Drawing.Size(163, 24);
            this.combo_type.TabIndex = 5;
            this.combo_type.SelectedIndexChanged += new System.EventHandler(this.combo_type_SelectedIndexChanged);
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Location = new System.Drawing.Point(120, 118);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(163, 22);
            this.textBox1.TabIndex = 4;
            // 
            // btn_update
            // 
            this.btn_update.Location = new System.Drawing.Point(28, 171);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(81, 23);
            this.btn_update.TabIndex = 2;
            this.btn_update.Text = "Оновити";
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(25, 108);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(84, 32);
            this.label17.TabIndex = 1;
            this.label17.Text = "Номер \r\nдокумента: ";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(25, 43);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(79, 16);
            this.label18.TabIndex = 0;
            this.label18.Text = "Тип освіти:";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.AliceBlue;
            this.panel7.Controls.Add(this.text_number);
            this.panel7.Controls.Add(this.text_Type);
            this.panel7.Controls.Add(this.Add_Educ);
            this.panel7.Controls.Add(this.label16);
            this.panel7.Controls.Add(this.label15);
            this.panel7.Location = new System.Drawing.Point(24, 41);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(524, 364);
            this.panel7.TabIndex = 2;
            // 
            // text_number
            // 
            this.text_number.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.text_number.Location = new System.Drawing.Point(120, 117);
            this.text_number.Name = "text_number";
            this.text_number.Size = new System.Drawing.Size(163, 22);
            this.text_number.TabIndex = 4;
            // 
            // text_Type
            // 
            this.text_Type.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.text_Type.Location = new System.Drawing.Point(120, 49);
            this.text_Type.Name = "text_Type";
            this.text_Type.Size = new System.Drawing.Size(163, 22);
            this.text_Type.TabIndex = 3;
            // 
            // Add_Educ
            // 
            this.Add_Educ.Location = new System.Drawing.Point(28, 171);
            this.Add_Educ.Name = "Add_Educ";
            this.Add_Educ.Size = new System.Drawing.Size(81, 23);
            this.Add_Educ.TabIndex = 2;
            this.Add_Educ.Text = "Додати";
            this.Add_Educ.UseVisualStyleBackColor = true;
            this.Add_Educ.Click += new System.EventHandler(this.Add_Educ_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(25, 108);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(84, 32);
            this.label16.TabIndex = 1;
            this.label16.Text = "Номер \r\nдокумента: ";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(25, 48);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(79, 16);
            this.label15.TabIndex = 0;
            this.label15.Text = "Тип освіти:";
            // 
            // Update_Education
            // 
            this.Update_Education.AutoSize = true;
            this.Update_Education.Location = new System.Drawing.Point(106, 14);
            this.Update_Education.Name = "Update_Education";
            this.Update_Education.Size = new System.Drawing.Size(152, 20);
            this.Update_Education.TabIndex = 1;
            this.Update_Education.Text = "Оновити/видалити";
            this.Update_Education.UseVisualStyleBackColor = true;
            // 
            // Add_Education
            // 
            this.Add_Education.AutoSize = true;
            this.Add_Education.Checked = true;
            this.Add_Education.Location = new System.Drawing.Point(24, 14);
            this.Add_Education.Name = "Add_Education";
            this.Add_Education.Size = new System.Drawing.Size(76, 20);
            this.Add_Education.TabIndex = 0;
            this.Add_Education.TabStop = true;
            this.Add_Education.Text = "Додати";
            this.Add_Education.UseVisualStyleBackColor = true;
            this.Add_Education.CheckedChanged += new System.EventHandler(this.Add_Education_CheckedChanged);
            // 
            // Skills_Citizen
            // 
            this.Skills_Citizen.Controls.Add(this.remove_skill_data);
            this.Skills_Citizen.Controls.Add(this.add_skill_to_data);
            this.Skills_Citizen.Controls.Add(this.Remove_skill);
            this.Skills_Citizen.Controls.Add(this.button_sentSkill);
            this.Skills_Citizen.Controls.Add(this.CItizen_skills_data);
            this.Skills_Citizen.Controls.Add(this.skill_box);
            this.Skills_Citizen.Location = new System.Drawing.Point(4, 25);
            this.Skills_Citizen.Name = "Skills_Citizen";
            this.Skills_Citizen.Size = new System.Drawing.Size(576, 435);
            this.Skills_Citizen.TabIndex = 4;
            this.Skills_Citizen.Text = "Навички";
            this.Skills_Citizen.UseVisualStyleBackColor = true;
            // 
            // remove_skill_data
            // 
            this.remove_skill_data.Location = new System.Drawing.Point(222, 45);
            this.remove_skill_data.Name = "remove_skill_data";
            this.remove_skill_data.Size = new System.Drawing.Size(196, 23);
            this.remove_skill_data.TabIndex = 5;
            this.remove_skill_data.Text = "Видалити обрану навичку";
            this.remove_skill_data.UseVisualStyleBackColor = true;
            this.remove_skill_data.Click += new System.EventHandler(this.button1_Click);
            // 
            // add_skill_to_data
            // 
            this.add_skill_to_data.Location = new System.Drawing.Point(24, 45);
            this.add_skill_to_data.Name = "add_skill_to_data";
            this.add_skill_to_data.Size = new System.Drawing.Size(176, 23);
            this.add_skill_to_data.TabIndex = 4;
            this.add_skill_to_data.Text = "Додати нову навичку";
            this.add_skill_to_data.UseVisualStyleBackColor = true;
            this.add_skill_to_data.Click += new System.EventHandler(this.add_skill_to_data_Click);
            // 
            // Remove_skill
            // 
            this.Remove_skill.Location = new System.Drawing.Point(479, 16);
            this.Remove_skill.Name = "Remove_skill";
            this.Remove_skill.Size = new System.Drawing.Size(49, 23);
            this.Remove_skill.TabIndex = 3;
            this.Remove_skill.Text = "-";
            this.Remove_skill.UseVisualStyleBackColor = true;
            this.Remove_skill.Click += new System.EventHandler(this.Remove_skill_Click);
            // 
            // button_sentSkill
            // 
            this.button_sentSkill.Location = new System.Drawing.Point(425, 15);
            this.button_sentSkill.Name = "button_sentSkill";
            this.button_sentSkill.Size = new System.Drawing.Size(48, 23);
            this.button_sentSkill.TabIndex = 2;
            this.button_sentSkill.Text = "+";
            this.button_sentSkill.UseVisualStyleBackColor = true;
            this.button_sentSkill.Click += new System.EventHandler(this.button_sentSkill_Click);
            // 
            // CItizen_skills_data
            // 
            this.CItizen_skills_data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CItizen_skills_data.Location = new System.Drawing.Point(24, 87);
            this.CItizen_skills_data.Name = "CItizen_skills_data";
            this.CItizen_skills_data.RowHeadersWidth = 51;
            this.CItizen_skills_data.RowTemplate.Height = 24;
            this.CItizen_skills_data.Size = new System.Drawing.Size(529, 339);
            this.CItizen_skills_data.TabIndex = 1;
            this.CItizen_skills_data.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // skill_box
            // 
            this.skill_box.FormattingEnabled = true;
            this.skill_box.Location = new System.Drawing.Point(24, 15);
            this.skill_box.Name = "skill_box";
            this.skill_box.Size = new System.Drawing.Size(394, 24);
            this.skill_box.TabIndex = 0;
            this.skill_box.TextChanged += new System.EventHandler(this.skill_box_TextChanged);
            // 
            // Redact_Form_cit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(607, 579);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Redact_Form_cit";
            this.Text = "Redact_Form_cit";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Redact_Form_cit_FormClosing);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.Citizen.ResumeLayout(false);
            this.Documents.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.Update_panel.ResumeLayout(false);
            this.Update_panel.PerformLayout();
            this.Add_panel.ResumeLayout(false);
            this.Add_panel.PerformLayout();
            this.Education.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.Skills_Citizen.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.CItizen_skills_data)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox day;
        private System.Windows.Forms.ComboBox month;
        private System.Windows.Forms.ComboBox year;
        private System.Windows.Forms.TextBox adress_text;
        private System.Windows.Forms.TextBox surname_text;
        private System.Windows.Forms.TextBox name_text;
        private System.Windows.Forms.CheckBox checkCrime;
        private System.Windows.Forms.CheckBox checkInv;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Comment;
        private System.Windows.Forms.TextBox text_phone;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Button Remove;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox phones_cit;
        private System.Windows.Forms.Button Comm_manage;
        private System.Windows.Forms.Button butt_;
        private System.Windows.Forms.Button butt_date;
        private System.Windows.Forms.Button butt_sur;
        private System.Windows.Forms.Button but_name;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Citizen;
        private System.Windows.Forms.TabPage Documents;
        private System.Windows.Forms.TabPage Education;
        private System.Windows.Forms.TabPage Skills_Citizen;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel Add_panel;
        private System.Windows.Forms.TextBox number_doc;
        private System.Windows.Forms.ComboBox day_doc;
        private System.Windows.Forms.ComboBox month_doc;
        private System.Windows.Forms.ComboBox year_doc;
        private System.Windows.Forms.ComboBox type_doc;
        private System.Windows.Forms.Button add_doc;
        private System.Windows.Forms.RadioButton update_doc_radio;
        private System.Windows.Forms.RadioButton add_doc_radio;
        private System.Windows.Forms.Panel Update_panel;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button update_doc;
        private System.Windows.Forms.TextBox number_doc_change;
        private System.Windows.Forms.ComboBox day_doc_change;
        private System.Windows.Forms.ComboBox month_doc_change;
        private System.Windows.Forms.ComboBox year_doc_change;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox choose_doc;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.RadioButton Add_Education;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.RadioButton Update_Education;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button Add_Educ;
        private System.Windows.Forms.TextBox text_Type;
        private System.Windows.Forms.TextBox text_number;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.ComboBox combo_type;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.ComboBox skill_box;
        private System.Windows.Forms.Button Remove_skill;
        private System.Windows.Forms.Button button_sentSkill;
        private System.Windows.Forms.DataGridView CItizen_skills_data;
        private System.Windows.Forms.Button remove_skill_data;
        private System.Windows.Forms.Button add_skill_to_data;
    }
}